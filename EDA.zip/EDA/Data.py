import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("Tuberculosis_Trends.csv")
print("\n First 5 rows: \n", df.head())
print("\n Info: \n")
df.info()
print("\n Description: \n")
print(df.describe())
print("\n Missing Value: \n")
print(df.isnull().sum())
print("\n Shape: \n", df.shape)
print("\nColumn Names: ", df.columns.tolist())

global_trend = df.groupby("Year")["TB_Cases"].sum()
plt.figure(figsize=(10,5))
sns.lineplot(x=global_trend.index, y=global_trend.values, marker='o')
plt.xlabel("Year")
plt.title("Global TB Cases Over Time")
plt.ylabel("Total TB Cases")
plt.grid(True)
plt.tight_layout()
plt.show()

top_countries = df.groupby("Country")["TB_Cases"].sum().sort_values(ascending=False).head(10)
plt.figure(figsize=(10,5))
sns.barplot(x=top_countries.values, y=top_countries.index, palette="Reds_r", legend=False)
plt.title("Top 10 Countries by Total TB Cases")
plt.xlabel("Total TB Cases")
plt.ylabel("Country")
plt.tight_layout()
plt.show()

plt.figure(figsize=(12,6))
sns.boxplot(data=df, x="Region", y="TB_Mortality_Rate")
plt.title("TB Mortality Rate by Region")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

plt.figure(figsize=(16,12))
numerical_cols = df.select_dtypes(include=[np.number])
corr = numerical_cols.corr()
sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.show()
filtered_df = df[
    (df["GDP_Per_Capita"] < df["GDP_Per_Capita"].quantile(0.95)) & 
    (df["TB_Cases"] < df["TB_Cases"].quantile(0.95))
]
g = sns.lmplot(
    data=filtered_df,
    x="GDP_Per_Capita",
    y="TB_Cases",
    hue="Income_Level",
    col="Region",  # Facet by region
    col_wrap=3,
    height=4,
    scatter_kws={"alpha": 0.5},
    line_kws={"color": "red"},
    x_estimator=np.mean,
    x_ci="sd",
    truncate=False,
    logx=True
)
g.set_axis_labels("GDP per Capita (USD, log)", "TB Cases")
plt.tight_layout()



